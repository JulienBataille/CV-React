import React from "react";

class Pays extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            locations: [],
            error: null,
        };
    }

    componentDidMount() {
        fetch('http://127.0.0.1:8000/infos')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                

                // Vérifiez si les données ont `message` et `message.locations` et si c'est un tableau
                if (data && data.message[0] && Array.isArray(data.message[0].location)) {
                    this.setState({ locations: data.message[0].location });
                } else {
                    console.error('Data does not contain valid locations data');
                    this.setState({ error: 'Data does not contain valid locations data' });
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                this.setState({ error: error.message });
            });
    }

    render() {
        const { locations, error } = this.state;

        if (error) {
            return <div>Error: {error}</div>;
        }

        if (locations.length === 0) {
            return <div>Loading...</div>;
        } 


        return (

            <>
           
                {locations.map(location =>
                (<li key={location.id}><span>{location.city}</span>{location.country}</li>
                ))} </>);
    }
}

export default Pays;